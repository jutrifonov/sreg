# sreg 0.7.1

* Initial CRAN submission.
