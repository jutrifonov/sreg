# sreg 0.7.1

# sreg 0.7.0

# sreg 0.6.9

# sreg 0.6.8

# sreg 0.6.7

# sreg 0.6.6

* Initial CRAN submission.
