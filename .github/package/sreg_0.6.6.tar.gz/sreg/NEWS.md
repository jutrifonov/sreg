# sreg 0.6.6

* Initial CRAN submission.
