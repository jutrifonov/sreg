# sreg 0.6.7

# sreg 0.6.6

* Initial CRAN submission.
