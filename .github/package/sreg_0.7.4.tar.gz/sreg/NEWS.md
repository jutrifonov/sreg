# sreg 0.7.4

# sreg 0.7.3

# sreg 0.7.2

# sreg 0.7.1

* Initial CRAN submission.
