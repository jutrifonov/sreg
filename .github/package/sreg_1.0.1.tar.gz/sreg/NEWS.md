# sreg 1.0.1
* Fixed a bug in the `sreg` function that caused it to return output for the unadjusted estimator instead of the adjusted estimator when `X` contained a single covariate.  
* Minor improvements and bug fixes.
# sreg 1.0.0
* Initial CRAN release. 
