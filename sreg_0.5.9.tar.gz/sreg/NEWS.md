# sreg 0.5.9

# sreg 0.5.8

* Initial CRAN submission.
